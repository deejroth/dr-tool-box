
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","LoremPixel\\LoremPixel"],["c","LoremPixel\\LoremPixelInterface"]];
