
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Google\\GoogleMaps\\GoogleMaps"],["c","Google\\GoogleMaps\\GoogleMapsInterface"],["c","LoremPixel\\LoremPixel"],["c","LoremPixel\\LoremPixelInterface"]];
